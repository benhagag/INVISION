# רילס לאינסטגרם 2.0

A Pen created on CodePen.io. Original URL: [https://codepen.io/omer-atzmon/pen/LYKOjEv](https://codepen.io/omer-atzmon/pen/LYKOjEv).

