document.addEventListener('DOMContentLoaded', function() {
    const platformButtons = document.querySelectorAll('.platform-btn');
    const tooltipContainer = document.getElementById('tooltip-container');

    const platformOptions = {
        facebook: ['פוסטים', 'מודעות ממומנות', 'סטוריז', 'אירועים', 'טפסי לידים', 'חנות מקוונת'],
        instagram: ['פוסט לפיד', 'פוסט לסטורי', 'IGTV'],
        tiktok: ['העלאת סרטון'],
        youtube: ['העלאת סרטון'],
        twitter: ['פרסום ציוץ'],
        'landing-page': ['ראשי', 'משני']
    };

    platformButtons.forEach(button => {
        button.addEventListener('mouseenter', function() {
            const platform = this.getAttribute('data-platform');
            const options = platformOptions[platform];
            const rect = this.getBoundingClientRect();
            const tooltipWidth = rect.width;

            tooltipContainer.innerHTML = `
                <div class="tooltip" style="top: ${rect.bottom + window.scrollY}px; left: ${rect.left + window.scrollX}px; width: ${tooltipWidth}px;">
                    <ul>
                        ${options.map(option => `<li onclick="selectOption('${option}')">${option}</li>`).join('')}
                    </ul>
                </div>
            `;
            const tooltip = tooltipContainer.querySelector('.tooltip');
            tooltip.style.display = 'block';

            const closeTooltip = () => {
                tooltip.style.display = 'none';
            };

            tooltip.addEventListener('mouseleave', closeTooltip);

            button.addEventListener('mouseleave', function() {
                setTimeout(() => {
                    if (!tooltip.matches(':hover') && !button.matches(':hover')) {
                        closeTooltip();
                    }
                }, 100);
            });
        });
    });
});

function selectOption(option) {
    alert(`נבחרה האפשרות: ${option}`);
}

function showManualForm() {
    document.getElementById('event-form').style.display = 'block';
    document.getElementById('invision-prompt').style.display = 'none';
    document.getElementById('event-preview').style.display = 'none';
}

function showInvisionPrompt() {
    document.getElementById('invision-prompt').style.display = 'block';
    document.getElementById('event-form').style.display = 'none';
    document.getElementById('event-preview').style.display = 'none';
}

function generateEvent() {
    const topic = document.getElementById('event-topic').value;
    const previewContent = document.getElementById('preview-content');

    const eventExample = {
        name: `אירוע ${topic} מיוחד`,
        type: Math.random() > 0.5 ? 'מקוון' : 'פיזי',
        date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toLocaleDateString('he-IL'),
        time: '19:00',
        location: Math.random() > 0.5 ? 'מרכז הקונגרסים תל אביב' : 'שידור חי בזום',
        description: `הצטרפו אלינו לאירוע מרתק בנושא ${topic}. נארח מומחים מובילים בתחום ונקיים פאנל שאלות ותשובות. אל תחמיצו!`
    };

    previewContent.innerHTML = `
        <p><strong>שם האירוע:</strong> ${eventExample.name}</p>
        <p><strong>סוג:</strong> ${eventExample.type}</p>
        <p><strong>תאריך:</strong> ${eventExample.date}</p>
        <p><strong>שעה:</strong> ${eventExample.time}</p>
        <p><strong>מיקום:</strong> ${eventExample.location}</p>
        <p><strong>תיאור:</strong> ${eventExample.description}</p>
    `;

    document.getElementById('event-preview').style.display = 'block';
    document.getElementById('invision-prompt').style.display = 'none';
}

function editEvent() {
    document.getElementById('event-form').style.display = 'block';
    document.getElementById('event-preview').style.display = 'none';

    const previewContent = document.getElementById('preview-content');
    document.getElementById('event-name').value = previewContent.querySelector('p:nth-child(1)').textContent.split(': ')[1];
    document.getElementById('event-type').value = previewContent.querySelector('p:nth-child(2)').textContent.split(': ')[1] === 'מקוון' ? 'online' : 'inperson';
    document.getElementById('event-location').value = previewContent.querySelector('p:nth-child(5)').textContent.split(': ')[1];
    document.getElementById('event-description').value = previewContent.querySelector('p:nth-child(6)').textContent.split(': ')[1];
}
