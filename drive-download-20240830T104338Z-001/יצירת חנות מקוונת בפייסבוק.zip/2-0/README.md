# חנות מקוונת בפייסבוק 2.0

A Pen created on CodePen.io. Original URL: [https://codepen.io/omer-atzmon/pen/GRbOzyx](https://codepen.io/omer-atzmon/pen/GRbOzyx).

