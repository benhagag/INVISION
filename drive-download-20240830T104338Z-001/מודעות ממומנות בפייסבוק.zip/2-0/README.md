# 2.0 מודעות ממומנות בפייסבוק

A Pen created on CodePen.io. Original URL: [https://codepen.io/omer-atzmon/pen/abgzrRX](https://codepen.io/omer-atzmon/pen/abgzrRX).

