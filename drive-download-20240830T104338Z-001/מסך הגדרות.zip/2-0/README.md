# מסך הגדרות 2.0

A Pen created on CodePen.io. Original URL: [https://codepen.io/omer-atzmon/pen/GRbOMZO](https://codepen.io/omer-atzmon/pen/GRbOMZO).

