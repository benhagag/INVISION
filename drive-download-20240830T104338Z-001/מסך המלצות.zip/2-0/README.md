# מסך המלצות 2.0

A Pen created on CodePen.io. Original URL: [https://codepen.io/omer-atzmon/pen/rNEwpma](https://codepen.io/omer-atzmon/pen/rNEwpma).

