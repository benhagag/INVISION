# מסך פרסום תוכן מעודכן 2.0

A Pen created on CodePen.io. Original URL: [https://codepen.io/omer-atzmon/pen/yLdPXdP](https://codepen.io/omer-atzmon/pen/yLdPXdP).

