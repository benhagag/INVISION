# תבנית דף נחיתה 2.0

A Pen created on CodePen.io. Original URL: [https://codepen.io/omer-atzmon/pen/eYweGYw](https://codepen.io/omer-atzmon/pen/eYweGYw).

